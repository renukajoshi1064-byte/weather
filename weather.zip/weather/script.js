const API_KEY = "635e296e6c984eea9a3154426261201";
const cityInput = document.getElementById("cityInput");
const suggestions = document.getElementById("suggestions");

cityInput.addEventListener("input", () => {
    const query = cityInput.value.trim();

    if (query.length < 2) {
        suggestions.innerHTML = "";
        return;
    }

    fetch(`https://api.weatherapi.com/v1/search.json?key=${API_KEY}&q=${query}`)
        .then(res => res.json())
        .then(data => {
            suggestions.innerHTML = "";
            data.forEach(city => {
                const li = document.createElement("li");
                li.textContent = `${city.name}, ${city.country}`;
                li.onclick = () => {
                    cityInput.value = city.name;
                    suggestions.innerHTML = "";
                    getWeather(city.name);
                };
                suggestions.appendChild(li);
            });
        });
});

function getWeather(city) {
    fetch(`https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${city}`)
        .then(res => res.json())
        .then(data => {
            document.getElementById("weatherInfo").classList.remove("hidden");

            document.getElementById("cityName").innerText =
                `${data.location.name}, ${data.location.country}`;

            document.getElementById("temperature").innerText =
                `${data.current.temp_c}°C`;

            document.getElementById("condition").innerText =
                data.current.condition.text;

            document.getElementById("humidity").innerText =
                data.current.humidity;

            document.getElementById("wind").innerText =
                data.current.wind_kph;

            document.getElementById("weatherIcon").src =
                `https:${data.current.condition.icon}`;
        });
}
